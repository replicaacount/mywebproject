// Compact holiday names
const holidays = {
  "2025-01-14": "Magh Bihu",
  "2025-01-15": "Magh Bihu",
  "2025-01-23": "Netaji B'day",
  "2025-01-26": "Rep Day",
  "2025-01-28": "Bathou",
  "2025-01-31": "MeDamMePhi",
  "2025-02-12": "Br Chilaray",
  "2025-03-14": "DolJatra",
  "2025-03-31": "Id-Fitr",
  "2025-04-14": "Bohag Bihu",
  "2025-04-15": "Bohag Bihu",
  "2025-04-16": "Bohag Bihu",
  "2025-04-18": "GoodFri",
  "2025-04-21": "Sadhani",
  "2025-04-28": "Dmdr Dev",
  "2025-05-01": "May Day",
  "2025-05-12": "Buddha Purn.",
  "2025-06-07": "Id-Zuha",
  "2025-06-12": "Madhabdeva",
  "2025-08-15": "Indep Day",
  "2025-08-25": "Sankardev",
  "2025-09-03": "Karam Puja",
  "2025-09-12": "Madbdev Tithi",
  "2025-09-14": "Janmasht.",
  "2025-09-29": "DurgaPuja",
  "2025-09-30": "DurgaPuja",
  "2025-10-01": "DurgaPuja",
  "2025-10-02": "Gandhi J.",
  "2025-10-18": "Kati Bihu",
  "2025-10-20": "Diwali",
  "2025-10-23": "Bhatri Dwi.",
  "2025-10-28": "Chhat Puja",
  "2025-11-05": "Guru Nanak",
  "2025-11-24": "Lachit Divas",
  "2025-12-02": "Asom Divas",
  "2025-12-25": "Xmas"
};

const holidayFullNames = {
  "2025-01-14": "Magh Bihu & Tusu Puja",
  "2025-01-15": "Magh Bihu & Tusu Puja",
  "2025-01-23": "Netaji’s Birthday",
  "2025-01-26": "Republic Day",
  "2025-01-28": "Gwthar Bathou San",
  "2025-01-31": "Me-Dam-Me-Phi",
  "2025-02-12": "Bir Chilaray Divas",
  "2025-03-14": "Dol Jatra",
  "2025-03-31": "Id-Ul-Fitre",
  "2025-04-14": "Bohag Bihu",
  "2025-04-15": "Bohag Bihu",
  "2025-04-16": "Bohag Bihu",
  "2025-04-18": "Good Friday",
  "2025-04-21": "Sati Sadhani Divas",
  "2025-04-28": "Tithi of Damodar Dev",
  "2025-05-01": "May Day",
  "2025-05-12": "Buddha Purnima",
  "2025-06-07": "Id-ul-Zuha",
  "2025-06-12": "Janmotsav of Sri Sri Madhabdeva",
  "2025-08-15": "Independence Day",
  "2025-08-25": "Tirubhav Tithi of Srimanta Sankardeva",
  "2025-09-03": "Karam Puja",
  "2025-09-12": "Tirubhav Tithi of Sri Sri Madhabdeva",
  "2025-09-14": "Janmastomi",
  "2025-09-29": "Durga Puja",
  "2025-09-30": "Durga Puja",
  "2025-10-01": "Durga Puja",
  "2025-10-02": "Vijoya Dashomi / Janmotsav of Sri Sri Sankardeva / Birthday of Mahatma Gandhi",
  "2025-10-18": "Kati Bihu",
  "2025-10-20": "Kali Puja & Diwali",
  "2025-10-23": "Bhatri Dwitiya",
  "2025-10-28": "Chhat Puja",
  "2025-11-05": "Guru Nanak's Birthday",
  "2025-11-24": "Lachit Divas",
  "2025-12-02": "Asom Divas (Su-Ka-Pha Divas)",
  "2025-12-25": "Christmas Day"
};

const year = 2025;
const monthsToShow = [1,2,3,4,5,6,7,8,9,10,11,12];
const daysOfWeek = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
const rootElem = document.getElementById("calendar-root");

function daysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

function getWeeklyLabel(dateObj) {
  const day = dateObj.getDay();
  if (day === 0) return "Sunday";
  if (day === 6) {
    const weekNum = Math.ceil(dateObj.getDate() / 7);
    if (weekNum === 2) return "2nd Sat";
    if (weekNum === 4) return "4th Sat";
  }
  return "";
}

monthsToShow.forEach(month => {
  const monthBlock = document.createElement("div");
  monthBlock.classList.add("month-block");

  const monthLabel = document.createElement("div");
  monthLabel.classList.add("month-label");
  monthLabel.textContent = new Date(year, month-1).toLocaleString('en-US', {month:'short', year:'2-digit'});
  monthBlock.appendChild(monthLabel);

  const calendar = document.createElement("div");
  calendar.classList.add("calendar");

  daysOfWeek.forEach(day => {
    const headerCell = document.createElement("div");
    headerCell.classList.add("calendar-header");
    headerCell.textContent = day;
    calendar.appendChild(headerCell);
  });

  const firstDay = new Date(year, month-1, 1).getDay();
  const totalDays = daysInMonth(year, month);

  for (let i = 0; i < firstDay; i++) {
    const emptyCell = document.createElement("div");
    emptyCell.classList.add("calendar-day");
    calendar.appendChild(emptyCell);
  }

  for (let date = 1; date <= totalDays; date++) {
    const dayCell = document.createElement("div");
    dayCell.classList.add("calendar-day");
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
    const dateNumber = document.createElement("div");
    dateNumber.classList.add("date-number");
    dateNumber.textContent = date;
    dayCell.appendChild(dateNumber);

    if (holidays[dateStr]) {
      // Official holiday in red
      const holidayLabel = document.createElement("div");
      holidayLabel.classList.add("holiday");
      holidayLabel.textContent = holidays[dateStr];
      dayCell.appendChild(holidayLabel);

      const tooltip = document.createElement("span");
      tooltip.classList.add("tooltip");
      tooltip.textContent = holidayFullNames[dateStr] || holidays[dateStr];
      dayCell.appendChild(tooltip);

    } else {
      // Show Sunday, 2nd/4th Sat—all in red, one label per day
      const d = new Date(year, month-1, date);
      const weeklyLabel = getWeeklyLabel(d);
      if (weeklyLabel) {
        const whLabel = document.createElement("div");
        // All weekly holidays (Sunday, 2nd/4th Sat) in red
        whLabel.classList.add(weeklyLabel === "Sunday" ? "sunday-holiday" : "weekly-holiday");
        whLabel.textContent = weeklyLabel;
        dayCell.appendChild(whLabel);

        const whTip = document.createElement("span");
        whTip.classList.add("tooltip");
        whTip.textContent =
          weeklyLabel === "2nd Sat"
            ? "2nd Saturday"
            : weeklyLabel === "4th Sat"
            ? "4th Saturday"
            : "Sunday";
        dayCell.appendChild(whTip);
      }
    }

    calendar.appendChild(dayCell);
  }

  monthBlock.appendChild(calendar);
  rootElem.appendChild(monthBlock);
});
